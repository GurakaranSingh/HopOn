﻿using System;
namespace HopOn.Model
{
    public class FileListModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string PhotoPath { get; set; }

    }
}

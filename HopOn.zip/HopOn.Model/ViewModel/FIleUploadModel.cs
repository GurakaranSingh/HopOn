﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HopOn.Model
{
    public class FIleUploadModel
    {
        public string Name { get; set; }
        public int Size { get; set; }
    }
}

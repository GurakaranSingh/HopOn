﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HopOn.Model
{
   public class EtagModel
    {
        public int PartNumber { get; set; }
        public string ETag { get; set; }
    }
}
